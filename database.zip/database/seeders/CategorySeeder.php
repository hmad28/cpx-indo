<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $categories = [
            ['name' => 'Jersey Futsal'],
            ['name' => 'Jersey Sepeda'],
            ['name' => 'Jersey Custom'],
            ['name' => 'Celana Olahraga'],
            ['name' => 'Setelan Jersey'],
        ];

        DB::table('categories')->insert($categories);
    }
}
