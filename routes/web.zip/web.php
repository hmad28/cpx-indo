<?php

use App\Models\Product;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CartController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\TestimonialController;
use App\Http\Controllers\BestSellerController;
use App\Models\Testimonial;

Route::get('/login', function () {
    return view('welcome');
});

Route::get('/profile', function () {
    return view('profile.edit');
});

Route::get('/', function () {
    $products = Product::with('category')->get()->map(function ($product) {
        $product->is_new = $product->created_at 
            ? $product->created_at->gt(now()->subDays(30)) 
            : false;
        return $product;
    });
    return view('home', compact('products'));
})->name('home');

Route::get('/about', function () {
    return view('about');
})->name('about');

Route::get('/testimonials', function () {
    $testimonials = Testimonial::all();
    return view('testimonials', compact('testimonials'));
})->name('testimonials');

Route::get('/custom', function () {
    return view('custom');
})->name('custom');

Route::get('/product-page/{product}', [ProductController::class, 'show'])->name('product-page');

Route::get('/dashboard', function () {
    return view('dashboard.index');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';

Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
Route::post('/cart/add/{product}', [CartController::class, 'add'])->name('cart.add');
Route::get('/cart/checkout', [CartController::class, 'checkout'])->name('cart.checkout');
Route::delete('/cart/remove/{id}', [CartController::class, 'remove'])->name('cart.remove');
Route::post('/cart/update/{product}', [CartController::class, 'updateQty'])->name('cart.update');
Route::post('/cart/update-qty', [CartController::class, 'updateQty'])->name('cart.updateQty');

Route::middleware(['auth'])->prefix('admin')->group(function () {
    Route::resource('products', ProductController::class);
    Route::resource('categories', CategoryController::class);
    Route::resource('testimonials', TestimonialController::class);
});

Route::get('/size-guide', function () {
    return view('sizes');
})->name('sizes');

Route::prefix('/dashboard/manage-best-seller')->name('best-seller.')->group(function () {
    Route::get('/', [BestSellerController::class, 'index'])->name('index');
    Route::post('/', [BestSellerController::class, 'store'])->name('store');
    Route::delete('/{id}', [BestSellerController::class, 'destroy'])->name('destroy');
});


