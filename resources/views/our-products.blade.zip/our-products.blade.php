<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CPX Official</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css"/>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    <link rel="icon" href="{{ asset('images/logo cpx.ico') }}" type="image/x-icon"/>
</head>
<body>
    <main>
        <x-header></x-header>

        <section id="products" class="py-10 md:py-20 2xl:pt-40 px-4 md:px-15"
            x-data="{
                filter: 'all',
                products: {{ $products->map(fn($p) => [
                    'id' => $p->id,
                    'name' => $p->name,
                    'price' => number_format($p->price, 0, ',', '.'),
                    'image' => $p->image,
                    'category' => $p->category->name,
                    'is_best_seller' => (bool) $p->is_best_seller,
                    'created_at' => $p->created_at ? $p->created_at->timestamp : 0,
                    'url' => route('product-page', $p->id),
                    'cartUrl' => route('cart.add', $p->id)
                ]) }},
                get filteredProducts() {
                    let items = this.products;

                    if (this.filter === 'best') {
                        items = items.filter(p => p.is_best_seller);
                    } else if (this.filter === 'new') {
                        items = [...items].sort((a, b) => b.created_at - a.created_at);
                    } else if (this.filter === 'custom') {
                        items = items.filter(p => p.category === 'Custom Jersey');
                    } else if (this.filter === 'accessories') {
                        items = items.filter(p => p.category === 'Accessories');
                    }
                    return items;
                }
            }">
            <div class="container mx-auto">
                <div class="w-full">
                    <div class="w-full mb-5">
                        <h1 class="text-4xl font-semibold mb-3">
                            Our Products Design
                            @isset($activeCategory)
                                <span class="text-lg text-gray-600">- {{ $activeCategory->name }}</span>
                            @endisset
                        </h1>
                        <div class="w-[50%] h-[1px] bg-zinc-900"></div>
                    </div>

                    <div class="w-ful flex justify-between">
                        <!-- filter buttons -->
                        <div class="flex gap-2 md:gap-5">
                            <template x-for="type in ['all','best','new','custom','accessories']" :key="type">
                                <button
                                    @click="filter = type"
                                    :class="filter === type ? 'bg-black text-white border-black' : 'border border-white'"
                                    class="py-1 px-2 text-xs md:text-base md:py-2 md:px-4 cursor-pointer hover:border hover:border-black capitalize">
                                    <span x-text="type === 'best' ? 'Best Seller' : (type === 'custom' ? 'Custom Design' : (type === 'accessories' ? 'Accessories' : (type === 'new' ? 'New' : 'All')))"></span>
                                </button>
                            </template>
                        </div>

                        <form class="flex items-center w-[300px]" action="" method="GET">
                            <label for="simple-search" class="sr-only">Search Product</label>
                            <div class="relative w-full">
                                <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                    <svg aria-hidden="true" class="w-5 h-5 text-gray-500 :text-gray-400" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                                <input type="text" id="simple-search" name="keyword" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2 :bg-gray-700 :border-gray-600 :placeholder-gray-400 :text-white :focus:ring-blue-500 :focus:border-blue-500" placeholder="Search product">
                            </div>
                        </form>
                    </div>

                    <!-- product grid -->
                    <div class="w-full py-8">
                        <div class="w-full grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                            <template x-for="product in filteredProducts" :key="product.id">
                                <div class="p-3 hover:border hover:border-black cursor-pointer shadow" x-transition>
                                    <div class="flex flex-col items-start relative">
                                        <a :href="product.url">
                                            <img :src="'../images/' + product.image" alt="" class="w-full h-[200px] sm:h-[280px] md:h-[230px] lg:h-[280px] 2xl:h-[348px] mb-2">
                                        </a>
                                        <h3 class="text-xs xl:text-sm text-gray-200 mb-1 md:mb-4 2xl:mb-2 py-1 px-2 rounded bg-red-500" x-text="product.category"></h3>
                                        <a :href="product.url" class="text-lg md:text-2xl hover:underline" x-text="product.name"></a>
                                        <div class="w-full flex md:flex-col md:items-start md:gap-2 lg:flex-row justify-between items-center mt-2">
                                            <h2 class="text-sm md:text-xl">Rp <span x-text="product.price"></span></h2>
                                            <a :href="'https://wa.me/6289696127555?text=Halo%20kak,%20saya%20mau%20beli%20' 
                                            + encodeURIComponent(product.name) 
                                            + '%20dengan%20harga%20Rp' 
                                            + product.price"
                                            target="_blank"
                                            class="py-2 px-4 text-xs xl:text-base rounded border hover:bg-black hover:text-white transition duration-300">
                                            Beli Sekarang
                                            </a>

                                        </div>
                                        <form :action="product.cartUrl" method="POST"
                                            class="absolute w-6 h-6 md:w-8 md:h-8 flex justify-center items-center right-0 border border-gray-500 rounded-full text-gray-500 hover:border-black hover:text-black">
                                            @csrf
                                            <button type="submit">
                                                <i class="fa-solid fa-cart-plus text-xs"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </template>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <x-footer></x-footer>
    </main>

    <x-script></x-script>
    <script>
        const qtyInput = document.getElementById('qty');
        const incrementBtn = document.getElementById('increment');
        const decrementBtn = document.getElementById('decrement');

        incrementBtn.addEventListener('click', () => {
            qtyInput.value = parseInt(qtyInput.value) + 1;
        });

        decrementBtn.addEventListener('click', () => {
            if (parseInt(qtyInput.value) > 1) {
                qtyInput.value = parseInt(qtyInput.value) - 1;
            }
        });
    </script>
</body>
</html>