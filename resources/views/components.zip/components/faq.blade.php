<section class="bg-white">
  <div class="py-8 px-4 mx-auto max-w-screen-xl sm:py-16 lg:px-6">
      <h2 class="mb-8 text-4xl tracking-tight font-extrabold text-gray-900 ">Pertanyaan yang sering diajukan</h2>
      <div class="grid pt-8 text-left border-t border-gray-200 md:gap-16 y-700 md:grid-cols-2">
          <div>
              <div class="mb-10">
                  <h3 class="flex items-center mb-4 text-lg font-medium text-gray-900 ">
                      <svg class="flex-shrink-0 mr-2 w-5 h-5 text-gray-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clip-rule="evenodd"></path></svg>
                      Apakah saya bisa pesan jersey custom sesuai desain sendiri?
                  </h3>
                  <p class="text-gray-500">Bisa banget. Kamu bisa kirim desain sendiri, atau tim desainer kami bantu bikinin sesuai permintaan.</p>
              </div>

              <div class="mb-10">                        
                  <h3 class="flex items-center mb-4 text-lg font-medium text-gray-900 ">
                      <svg class="flex-shrink-0 mr-2 w-5 h-5 text-gray-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clip-rule="evenodd"></path></svg>
                      Apa saja bahan yang tersedia untuk jersey?
                  </h3>
                  <p class="text-gray-500">Umumnya tersedia bahan dryfit, hyget, atau kombinasi polyester yang adem, ringan, dan cocok buat olahraga.</p>
              </div>

              <div class="mb-10">
                  <h3 class="flex items-center mb-4 text-lg font-medium text-gray-900 ">
                      <svg class="flex-shrink-0 mr-2 w-5 h-5 text-gray-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clip-rule="evenodd"></path></svg>
                      Berapa lama proses pembuatan jersey custom?
                  </h3>
                  <p class="text-gray-500">Biasanya 7–14 hari kerja tergantung jumlah pesanan dan tingkat kerumitan desain.</p>
                  <p class="text-gray-500">Feel free to <a href="#" class="font-medium underline text-primary-600 ry-500 hover:no-underline" target="_blank" rel="noreferrer">contact us</a> and we'll help you out as soon as we can.</p>
              </div>

              <div class="mb-10">
                  <h3 class="flex items-center mb-4 text-lg font-medium text-gray-900 ">
                      <svg class="flex-shrink-0 mr-2 w-5 h-5 text-gray-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clip-rule="evenodd"></path></svg>
                      Apakah bisa mencetak nama dan nomor di jersey?
                  </h3>
                  <p class="text-gray-500">Bisa. Nama, nomor, bahkan logo tim atau sponsor bisa dicetak sesuai permintaan. </p>
                  <p class="text-gray-500">Find out more information by <a href="#" class="font-medium underline text-primary-600 ry-500 hover:no-underline">reading the license</a>.</p>
              </div>
          </div>

          <div>
              <div class="mb-10">
                  <h3 class="flex items-center mb-4 text-lg font-medium text-gray-900 ">
                      <svg class="flex-shrink-0 mr-2 w-5 h-5 text-gray-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clip-rule="evenodd"></path></svg>
                      Apakah ada minimum order untuk jersey custom?
                  </h3>
                  <p class="text-gray-500">Biasanya ada, sekitar 6–12 pcs. Tapi ada juga yang terima satuan dengan harga berbeda. </p>
              </div>
              
              <div class="mb-10">
                  <h3 class="flex items-center mb-4 text-lg font-medium text-gray-900 ">
                      <svg class="flex-shrink-0 mr-2 w-5 h-5 text-gray-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clip-rule="evenodd"></path></svg>
                    Bagaimana cara memesan jersey?
                  </h3>
                  <p class="text-gray-500">Umumnya tinggal hubungi admin, kirim desain/ide, pilih bahan & ukuran, lalu lakukan pembayaran DP, setelah itu jersey langsung diproduksi.</p>
              </div>

              <div class="mb-10">
                  <h3 class="flex items-center mb-4 text-lg font-medium text-gray-900 ">
                      <svg class="flex-shrink-0 mr-2 w-5 h-5 text-gray-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clip-rule="evenodd"></path></svg>
                      Apakah tersedia ready stock jersey?
                  </h3>
                  <p class="text-gray-500">Beberapa model ada yang ready stock (desain umum), tapi untuk custom umumnya dibuat sesuai pesanan.</p>
              </div>

              <div class="mb-10">
                  <h3 class="flex items-center mb-4 text-lg font-medium text-gray-900 ">
                      <svg class="flex-shrink-0 mr-2 w-5 h-5 text-gray-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clip-rule="evenodd"></path></svg>
                      Apakah bisa retur atau ganti jersey jika ukurannya salah?
                  </h3>
                  <p class="text-gray-500">Biasanya tidak bisa retur karena custom dibuat khusus, kecuali ada kesalahan produksi dari pihak penjual.</p>
              </div>
          </div>
      </div>
  </div>
</section>