<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use App\Models\Size;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $products = Product::paginate(5);
        $categories = Category::all();
         $sizes = Size::all();
        return view('admin.products.index', compact(['products', 'categories', 'sizes']));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|max:100',
            'price' => 'required|numeric',
            'image' => 'required|image',
            'size_image' => 'required|image',
            'description' => 'required|max:2000',
            'kelebihan' => 'nullable|array',
            'kelebihan.*' => 'nullable|string|max:255', // untuk setiap elemen kelebihan
            'category_id' => 'required|exists:categories,id',
            'sizes' => 'array',
            'sizes.*' => 'exists:sizes,id',
        ]);

        $image = $request->file('image');
        $imageName = time() . '.' . $image->extension();
        $image->move(public_path('images'), $imageName);
        
        $sizeImage = $request->file('size_image');
        $sizeImageName = time() . '.' . $sizeImage->extension();
        $sizeImage->move(public_path('images'), $sizeImageName);

        $product = Product::create([
            'name' => $request->name,
            'price' => $request->price,
            'image' => $imageName,
            'size_image' => $sizeImageName,
            'description' => $request->description,
            'kelebihan' => json_encode($request->kelebihan ?? []),
            'category_id' => $request->category_id,
        ]);

        $product->sizes()->sync($request->sizes ?? []);
        return redirect()->route('products.index')->with('success', 'Produk berhasil ditambahkan!');
    }

    /**
     * Display the specified resource.
     */
    public function show(Product $product)
    {
        $products = Product::paginate(4);
        $sizes = $product->sizes; // ambil ukuran yg tersedia utk produk ini
        return view('product-page', compact('product', 'sizes', 'products'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Product $product)
    {
        $data = $request->validate([
            'name' => 'sometimes|max:100',
            'price' => 'sometimes|numeric',
            'image' => 'sometimes|image|mimes:jpg,jpeg,png',
            'size_image' => 'sometimes|image|mimes:jpg,jpeg,png',
            'description' => 'sometimes|max:2000',
            'kelebihan' => 'sometimes|array',
            'kelebihan.*' => 'nullable|string|max:255',
            'category_id' => 'sometimes|exists:categories,id',
            'sizes' => 'sometimes|array',
            'sizes.*' => 'exists:sizes,id',
        ]);

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = time() . '.' . $image->extension();
            $image->move(public_path('images'), $imageName);
            $data['image'] = $imageName;
        }

        if ($request->hasFile('size_image')) {
            $sizeImage = $request->file('size_image');
            $sizeImageName = time() . '.' . $sizeImage->extension();
            $sizeImage->move(public_path('images'), $sizeImageName);
            $data['size_image'] = $sizeImageName;
        }

        if ($request->filled('kelebihan')) {
            $data['kelebihan'] = json_encode($request->kelebihan);
        }

        $product->update($data);
        $product->sizes()->sync($request->sizes ?? []);

        return redirect()->route('products.index')->with('success', 'Produk berhasil diperbarui!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Product $product)
    {
        $product->delete();
        return redirect()->route('products.index')->with('success', 'The product '. $product->name .' has been deleted successfully!');
    }

    public function setBestSeller(Request $request, Product $product)
    {
        $product->update([
            'is_best_seller' => $request->boolean('is_best_seller'),
        ]);

        return redirect()->back()->with('success', 'Produk berhasil diperbarui sebagai Best Seller');
    }

    public function byCategory($slug)
    {
        $category = Category::where('slug', $slug)->firstOrFail();
        $products = Product::where('category_id', $category->id)->get();

        return view('our-products', [
            'products' => $products,
            'activeCategory' => $category, // penting buat ditampilin di view
        ]);
    }


}
