<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Size;

class CartController extends Controller
{
    public function index(Request $request)
    {
        $products = Product::paginate(3);
        $cart = session()->get('cart', []);
        return view('cart.index', compact(['cart', 'products']));
    }

    public function add(Request $request, Product $product)
    {
        $cart = session()->get('cart', []);
        $qty = $request->input('qty', 1);
        $size = $request->input('size'); // ambil dari radio button

        // bikin key unik supaya size berbeda tetap bisa masuk cart
        $cartKey = $product->id . '-' . $size;

        $cart[$cartKey] = [
            'image' => $product->image,
            'name' => $product->name,
            'qty' => ($cart[$cartKey]['qty'] ?? 0) + $qty,
            'price' => $product->price,
            'size' => $size,
            'slug' => $product->slug,
        ];

        session()->put('cart', $cart);
        // session()->forget('cart');


        return redirect()->route('cart.index');
    }

    public function checkout()
    {
        $cart = session()->get('cart', []);
        $total = 0;
        $message = "Halo, saya mau pesan:\n";
        foreach($cart as $c){
            $subtotal = $c['qty'] * $c['price'];
            $total += $subtotal;
            $message .= "- {$c['name']} (Size: {$c['size']}) x{$c['qty']} = Rp " . number_format($subtotal, 0, ',', '.') . "\n";
        }
        $message .= "\nTotal: Rp " . number_format($total, 0, ',', '.');

        $waNumber = "62851720036670";
        $waUrl = "https://wa.me/{$waNumber}?text=" . urlencode($message);

        return redirect($waUrl);
    }

    public function remove($id)
    {
        $cart = session()->get('cart', []);
        if(isset($cart[$id])) {
            unset($cart[$id]);
            session()->put('cart', $cart);
        }
        return redirect()->route('cart.index');
    }

    // public function updateQty(Request $request, Product $product)
    // {
    //     $cart = session()->get('cart', []);

    //     if (isset($cart[$product->id])) {
    //         $qty = (int) $request->input('qty');
    //         if ($qty < 1) {
    //             unset($cart[$product->id]);
    //         } else {
    //             $cart[$product->id]['qty'] = $qty;
    //         }

    //         session()->put('cart', $cart);
    //     }

    //     return redirect()->route('cart.index');
    // }

    public function updateQty(Request $request)
    {
        $productId = $request->input('product_id');
        $qty = $request->input('qty');

        $cart = session()->get('cart', []);

        if (isset($cart[$productId])) {
            $cart[$productId]['qty'] = $qty;
            session()->put('cart', $cart);

            $subtotal = $cart[$productId]['qty'] * $cart[$productId]['price'];
            $total = collect($cart)->sum(fn($item) => $item['qty'] * $item['price']);

            return response()->json([
                'success' => true,
                'subtotal' => number_format($subtotal, 0, ',', '.'),
                'total' => number_format($total, 0, ',', '.')
            ]);
        }

        return response()->json(['success' => false]);
    }



}

